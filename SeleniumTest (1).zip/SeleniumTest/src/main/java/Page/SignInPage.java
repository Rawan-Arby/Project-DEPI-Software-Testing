package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class SignInPage {
    private WebDriver driver;

    public SignInPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterEmail(String email) {
        try {
            WebElement emailField = driver.findElement(By.name("email"));
            emailField.clear();
            emailField.sendKeys(email);
        } catch (Exception e) {
            System.out.println("Error entering email: " + e.getMessage());
        }
    }

    public void enterPassword(String password) {
        try {
            WebElement passwordField = driver.findElement(By.name("password"));
            passwordField.clear();
            passwordField.sendKeys(password);
        } catch (Exception e) {
            System.out.println("Error entering password: " + e.getMessage());
        }
    }

    public void clickLogin() {
        try {
            WebElement loginButton = driver.findElement(By.id("submit-login"));
            loginButton.click();
        } catch (Exception e) {
            System.out.println("Error clicking login button: " + e.getMessage());
        }
    }

    public void clickLoginPageBtn() {
        try {
            WebElement loginPageBtn = driver.findElement(By.cssSelector("#_desktop_user_info > div > a > span"));
            loginPageBtn.click();
        } catch (Exception e) {
            System.out.println("Error clicking login page button: " + e.getMessage());
        }
    }

    public void login(String email, String password) {
        enterEmail(email);
        enterPassword(password);
        clickLogin();
    }
    public boolean Testdisplay() {
    try {
        WebElement contenthome = driver.findElement(By.cssSelector("#content > section:nth-child(2) > h2"));
       Assert.assertTrue(contenthome.isDisplayed(), "Expected error alert for empty fields not displayed.");
       return contenthome.isDisplayed();
    } catch (Exception e) {
       return false;
    }
}
}