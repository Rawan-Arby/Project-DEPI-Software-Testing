package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class cart_page {
    private WebDriver driver;
    private WebDriverWait wait;

    public cart_page(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    private By cartIcon = By.cssSelector("a#_desktop_cart");
    private By cartCount = By.cssSelector("span.cart-products-count");
    private By emptyCartMessage = By.cssSelector(".no-items");
    private By productpage = By.xpath("//*[@id=\"content\"]/section[1]/div/div[1]/article/div/div[1]/a/picture/img");

    private By productAddButton = By.cssSelector("button.add-to-cart"); // صححي حسب الموقع لو مختلف

    private By cartItems = By.cssSelector(".cart-item");
    private By checkoutButton = By.cssSelector(".checkout a");
    private By continueShoppingButton = By.cssSelector(".continue.btn.btn-primary");

    // Methods

    public void clickCartIcon() {
        wait.until(ExpectedConditions.elementToBeClickable(cartIcon)).click();
    }

    public String getCartCountText() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(cartCount)).getText().replaceAll("[^0-9]", "");
        } catch (Exception e) {
            return "0";
        }
    }

    public boolean isCartEmptyMessageDisplayed() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(emptyCartMessage)).isDisplayed();
    }

    public void addProductToCart() {
        wait.until(ExpectedConditions.elementToBeClickable(productAddButton)).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".cart-confirmation")));
    }
    public void Clickproduct() {
        driver.findElement(productpage).click();

    }
    public int getCartItemCount() {
        List<WebElement> items = driver.findElements(cartItems);
        return items.size();
    }

    public void clickCheckout() {
        wait.until(ExpectedConditions.elementToBeClickable(checkoutButton)).click();
    }

    public void clickContinueShopping() {
        wait.until(ExpectedConditions.elementToBeClickable(continueShoppingButton)).click();
    }

    public void removeAllItemsFromCart() {
        List<WebElement> items = driver.findElements(cartItems);
        for (WebElement item : items) {
            item.findElement(By.cssSelector(".remove-from-cart")).click();

            wait.until(ExpectedConditions.stalenessOf(item));
        }
    }
}