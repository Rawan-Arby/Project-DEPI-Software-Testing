package Page;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class home_page {
    private WebDriver driver;
    private WebDriverWait wait;

    // Locators
    @FindBy(xpath = "//*[@id='_desktop_logo']/h1/a/img")
    private WebElement logo;

    @FindBy(className = "user-info")
    private WebElement signInButton;

    @FindBy(id = "search_widget")
    private WebElement searchBar;

    @FindBy(css = "#search_widget input.ui-autocomplete-input")
    private WebElement searchInput;

    @FindBy(css = "#main-menu > ul > li")
    private List<WebElement> navigationMenuItems;

    @FindBy(className = "cart-preview")
    private WebElement cartIcon;

    @FindBy(css = ".cart-products-count")
    private WebElement cartCount;

    @FindBy(css = "footer .links a")
    private List<WebElement> footerLinks;

    // Constructor
    public home_page(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        PageFactory.initElements(driver, this);
    }

    // Methods
    
    public boolean isLogoDisplayed() {
        return isElementVisible(logo);
    }

    public boolean isSignInButtonDisplayed() {
        return isElementClickable(signInButton);
    }

    public void clickSignIn() {
        signInButton.click();
    }

    public boolean isSearchBarDisplayed() {
        return isElementVisible(searchBar);
    }

    public void enterSearchQuery(String query) {
        searchInput.sendKeys(query);
    }

    public boolean areNavigationItemsDisplayed() {
        return !navigationMenuItems.isEmpty();
    }

    public int getNavigationItemsCount() {
        return navigationMenuItems.size();
    }

    public boolean isCartIconDisplayed() {
        return isElementVisible(cartIcon);
    }

    public String getCartCount() {
        return cartCount.getText();
    }

    public boolean areFooterLinksDisplayed() {
        return !footerLinks.isEmpty();
    }

    public int getFooterLinksCount() {
        return footerLinks.size();
    }
    

    // Utility Methods
    private boolean isElementVisible(WebElement element) {
        try {
            return wait.until(ExpectedConditions.visibilityOf(element)).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isElementClickable(WebElement element) {
        try {
            return wait.until(ExpectedConditions.elementToBeClickable(element)).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}