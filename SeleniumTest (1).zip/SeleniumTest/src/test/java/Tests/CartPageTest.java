package Tests;

import Page.cart_page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class CartPageTest {

    private WebDriver driver;
    private cart_page cartPage;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://demo.prestashop.com/#/en/front");

        // Switch to main frame
        driver.switchTo().frame(0);
        cartPage = new cart_page(driver);
    }

    @Test(priority = 1)
    public void testCartIconDisplayed() {
        cartPage.clickCartIcon();
        Assert.assertTrue(Integer.parseInt(cartPage.getCartCountText()) == 0);
        Assert.assertTrue(cartPage.isCartEmptyMessageDisplayed(), "[ERROR] Empty cart message not shown.");
    }

    @Test(priority = 2)
    public void testAddItemToCart() {
        cartPage.addProductToCart();
        Assert.assertTrue(Integer.parseInt(cartPage.getCartCountText()) > 0, "[ERROR] Cart count did not update.");
    }

    @Test(priority = 3)
    public void testCartItemDisplayed() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        cartPage.clickCartIcon();

        Assert.assertTrue(cartPage.getCartItemCount() > 0, "[ERROR] Item not displayed in cart.");
    }

    @Test(priority = 4)
    public void testProceedToCheckout() {
        cartPage.clickCartIcon();
        cartPage.clickCheckout();
        Assert.assertTrue(driver.getCurrentUrl().contains("order"), "[ERROR] Did not navigate to checkout.");
    }

    @Test(priority = 5)
    public void testContinueShopping() {
        driver.navigate().back();
        cartPage.clickCartIcon();
        cartPage.clickContinueShopping();
        Assert.assertTrue(driver.getCurrentUrl().contains("index"), "[ERROR] Did not return to home.");
    }

    @Test(priority = 6)
    public void testRemoveItemFromCart() {
        cartPage.clickCartIcon();
        cartPage.removeAllItemsFromCart();
        Assert.assertTrue(Integer.parseInt(cartPage.getCartCountText()) == 0, "[ERROR] Cart not cleared.");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
