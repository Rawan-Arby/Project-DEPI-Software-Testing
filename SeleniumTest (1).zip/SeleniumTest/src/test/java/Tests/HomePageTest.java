package Tests;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import Page.SignInPage;
import Page.cart_page;
import Page.home_page;

public class HomePageTest {

    private WebDriver driver;
    private home_page homePage;
    private SignInPage signInPage;
    private cart_page cartPage;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://demo.prestashop.com/#/en/front");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); 
        switchToMainFrame();
        homePage = new home_page(driver);
        signInPage = new SignInPage(driver);
        cartPage = new cart_page(driver);
    }

    private void switchToMainFrame() {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(0));
        } catch (TimeoutException e) {
            System.out.println("[WARN] Main frame not found, continuing without frame switch.");
        }
    }

    @Test(priority = 1)
    public void testLogoIsDisplayed() {
        Assert.assertTrue(homePage.isLogoDisplayed(), "[ERROR] Logo is not displayed on the home page.");
    }

    @Test(priority = 2)
    public void testSignInButtonIsDisplayed() {
        Assert.assertTrue(homePage.isSignInButtonDisplayed(), "[ERROR] Sign In button is not displayed.");
    }

//    @Test(priority = 3)
//    public void testSearchBarIsDisplayedAndFunctional() {
//        Assert.assertTrue(homePage.isSearchBarDisplayed(), "[ERROR] Search bar is not displayed.");
//        homePage.enterSearchQuery("Test Search");
//        Assert.assertTrue(homePage.isSearchResultsDisplayed(), "[ERROR] Search results not displayed.");
//    }

    @Test(dataProvider = "loginData", priority = 4)
    public void testLogin(String email, String password, boolean isSuccess) {
        signInPage.login(email, password);
        if (isSuccess) {
            WebElement userInfo = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#_desktop_user_info")));
            Assert.assertTrue(userInfo.isDisplayed(), "[ERROR] Login failed: User info not displayed");
        } else {
            Assert.assertTrue(signInPage.Testdisplay(), "[ERROR] Expected error alert not displayed.");
        }
    }

    @DataProvider(name = "loginData")
    public Object[][] loginData() {
        return new Object[][] {
            {"alshaimaaaboalela@gmail.com", "My Mom632004", true},
            {"wrong@example.com", "wrongpassword", false},
            {"", "", false}
        };
    }
    @Test
    public void Gotoproduct() {
    	cartPage.Clickproduct();
       
    }
    @Test(priority = 5,dependsOnMethods="Gotoproduct")
    public void testAddItemToCart() {
        driver.switchTo().defaultContent();
        switchToMainFrame();

        cartPage.addProductToCart();

        new WebDriverWait(driver, Duration.ofSeconds(10)).until(d -> {
            String countText = cartPage.getCartCountText();
            return !countText.isEmpty() && Integer.parseInt(countText) > 0;
        });

        Assert.assertTrue(Integer.parseInt(cartPage.getCartCountText()) > 0, "[ERROR] Cart count did not update.");
    }


    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

