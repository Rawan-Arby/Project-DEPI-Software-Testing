package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import Page.SignInPage;

import java.time.Duration;

public class SignInTest {
    WebDriver driver;
    SignInPage signInPage;

    @BeforeMethod
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://demo.prestashop.com/#/en/front");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlContains("front"));

        try {
            switchToMainFrame();
        } catch (Exception e) {
            System.out.println("Error switching to iframe: " + e.getMessage());
        }

        signInPage = new SignInPage(driver);
        try {
            signInPage.clickLoginPageBtn();
        } catch (Exception e) {
            System.out.println("Error clicking login page button: " + e.getMessage());
        }
    }

    @Test
    public void testValidLogin() {
        try {
            signInPage.login("alshaimaaaboalela@gmail.com", "My Mom632004");
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement userInfo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#_desktop_user_info")));
            Assert.assertTrue(userInfo.isDisplayed(), "Login failed: User info not displayed");
        } catch (Exception e) {
            System.out.println("Test failed: " + e.getMessage());
            Assert.fail("Login test failed due to: " + e.getMessage());
        }
    }

    @Test
    public void testEmptyEmailAndPassword() {
        try {
            signInPage.login("", "");
            WebElement alert = driver.findElement(By.cssSelector(".alert-danger"));
            Assert.assertTrue(alert.isDisplayed(), "Expected error alert for empty fields not displayed.");
        } catch (Exception e) {
            Assert.fail("Test failed: " + e.getMessage());
        }
    }

    @Test
    public void testInvalidEmailFormat() {
        try {
            signInPage.login("invalidemail", "My Mom632004");
            WebElement alert = driver.findElement(By.cssSelector(".alert-danger"));
            Assert.assertTrue(alert.isDisplayed(), "Expected error alert for invalid email not displayed.");
        } catch (Exception e) {
            Assert.fail("Test failed: " + e.getMessage());
        }
    }

    @Test
    public void testWrongCredentials() {
        try {
            signInPage.login("wrong@example.com", "wrongpassword");
            WebElement alert = driver.findElement(By.cssSelector(".alert-danger"));
            Assert.assertTrue(alert.isDisplayed(), "Expected alert for wrong credentials not displayed.");
        } catch (Exception e) {
            Assert.fail("Test failed: " + e.getMessage());
        }
    }

    @Test
    public void testLoginButtonIsClickable() {
        try {
            WebElement emailField = driver.findElement(By.name("email"));
            WebElement passwordField = driver.findElement(By.name("password"));
            emailField.sendKeys("alshaimaaaboalela@gmail.com");
            passwordField.sendKeys("My Mom632004");
            WebElement loginBtn = driver.findElement(By.id("submit-login"));
            Assert.assertTrue(loginBtn.isDisplayed() && loginBtn.isEnabled(), "Login button is not clickable.");
        } catch (Exception e) {
            Assert.fail("Test failed: " + e.getMessage());
        }
    }

    @Test
    public void testLoginPageBtnIsWorking() {
        try {
            driver.navigate().refresh();
            switchToMainFrame();
            signInPage.clickLoginPageBtn();
            WebElement loginForm = driver.findElement(By.id("login-form"));
            Assert.assertTrue(loginForm.isDisplayed(), "Login form is not visible.");
        } catch (Exception e) {
            Assert.fail("Test failed: " + e.getMessage());
        }
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    private void switchToMainFrame() {
        try {
            WebElement iframe = driver.findElement(By.cssSelector("iframe.demo-frame"));
            driver.switchTo().frame(iframe);
        } catch (Exception e) {
            System.out.println("Failed to switch to iframe: " + e.getMessage());
        }
    }
}
